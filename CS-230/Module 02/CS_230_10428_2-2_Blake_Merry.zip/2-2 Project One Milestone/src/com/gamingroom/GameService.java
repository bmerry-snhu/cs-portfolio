package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

	/*
	 * Singleton instance of the GameService.
	 */
	private static GameService instance;
	
	/*
	 * Private constructor prevents other classes from creating
	 * additional GameService instances.
	 */
	private GameService() {
	}

	/*
	 * Returns the single GameService instance, creating one if
	 * necessary.
	 * 
	 * @return the singleton GameService instance
	 */
	public static GameService getInstance() {
		if (instance == null) {
			instance = new GameService();
		}

		return instance;
	}


	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;

		/*
		 * Use Iterator through all existing games to determine whether a
		 * game with the requested name already exists.
		 */ 
		Iterator<Game> iterator = games.iterator();
		
		// if found, simply return the existing instance
		while (iterator.hasNext()) {
			Game existingGame = iterator.next();

			if (existingGame.getName().equals(name)) {
				game = existingGame;
				break;
			}
		}

		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		Iterator<Game> iterator = games.iterator();

		// if found, simply assign that instance to the local variable
		while (iterator.hasNext()) {
			Game currentGame = iterator.next();

			if (currentGame.getId() == id) {
				game = currentGame;
				break;
			}
		}

		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		Iterator<Game> iterator = games.iterator();

		// if found, simply assign that instance to the local variable
		while (iterator.hasNext()) {
			Game currentGame = iterator.next();

			if (currentGame.getName().equals(name)) {
				game = currentGame;
				break;
			}
		}

		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
}
