SELECT 
	vendor_name, 
    vendor_contact_last_name, 
    vendor_contact_first_name 
FROM 
	ap.vendors 
ORDER BY
	vendor_contact_last_name,
    vendor_contact_first_name;